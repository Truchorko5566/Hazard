---
name: Question
about: Have a question? Ask here!
title: 'Hazard Nuker [BUG]'
labels: question
assignees: [DeKrypted,Rdimo]

---

**Type your question below.**

